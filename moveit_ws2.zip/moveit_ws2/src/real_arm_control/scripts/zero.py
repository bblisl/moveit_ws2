#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float32
import ServoControl

class ServoController:
    def __init__(self):
        rospy.init_node('quad_servo_controller')
        
        # 参数配置
        self.base_move_time = 2000    # 基础运动时间2000ms
        
        # 初始化串口
        self.init_serial()
        
        rospy.loginfo("四舵机控制节点已启动")
        self.move_servos_to_target()
        
        rospy.on_shutdown(self.shutdown)

    def init_serial(self):
        """初始化串口连接"""
        try:
            if not ServoControl.serialHandle.is_open:
                ServoControl.serialHandle.open()
            rospy.loginfo("串口初始化成功")
        except Exception as e:
            rospy.logerr(f"串口初始化失败: {str(e)}")
            rospy.signal_shutdown("硬件故障")

    def angle_to_pulse(self, angle):
        """角度转脉冲（0-240°转0-1000脉冲）"""
        angle = max(0.0, min(240.0, angle))  # 安全限幅
        return int((angle / 240.0) * 1000)

    def move_servos_sync(self, servo_list, angle_list, move_time):
        """多舵机同步控制"""
        try:
            # 生成参数列表 [ID1, pulse1, ID2, pulse2...]
            params = []
            for sid, angle in zip(servo_list, angle_list):
                pulse = self.angle_to_pulse(angle)
                params.extend([sid, pulse])
            
            # 发送同步控制指令
            ServoControl.setMoreBusServoMove(
                servos=params,
                servos_count=len(servo_list),
                time=move_time
            )
            
            rospy.loginfo(f"同步控制舵机{servo_list}到角度{angle_list}")
            return True
        except Exception as e:
            rospy.logerr(f"同步控制失败: {str(e)}")
            return False

    def move_servos_to_target(self):
        """执行目标位置运动"""
        # 目标角度设置
        target_angles = {
            1: 145.2,
            2: 120.0,
            3: 217.29,
            4: 120.0
        }
        
        # 转换为有序列表
        servo_ids = [1, 2, 3, 4]
        angles = [target_angles[id] for id in servo_ids]
        
        # 发送同步控制指令
        if self.move_servos_sync(servo_ids, angles, self.base_move_time):
            # 计算运动时间+缓冲
            total_time = self.base_move_time/1000 + 0.5
            rospy.loginfo(f"运动执行中，预计耗时{total_time}秒...")
            rospy.sleep(total_time)
            rospy.loginfo("运动完成")
        else:
            rospy.logerr("运动指令发送失败")

    def shutdown(self):
        """资源清理"""
        if ServoControl.serialHandle.is_open:
            ServoControl.serialHandle.close()
        rospy.loginfo("节点已安全关闭")

if __name__ == '__main__':
    try:
        controller = ServoController()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass