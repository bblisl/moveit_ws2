#!/usr/bin/env python3
import rospy
import threading
from std_msgs.msg import Float32MultiArray
import serial

class ServoReader:
    def __init__(self):
        rospy.init_node('servo_angle_reader')
        
        # 参数配置
        self.servo_ids = [1, 2, 3, 4]  # 要读取的舵机ID
        self.read_interval = 0.02     # 20ms读取周期（50Hz）
        self.serial_port = "/dev/ttyS0"  # 根据实际修改
        self.baudrate = 9600
        
        # ROS初始化
        self.pub = rospy.Publisher('/servo_positions', Float32MultiArray, queue_size=10)
        
        # 串口初始化
        self.ser = serial.Serial(self.serial_port, self.baudrate, timeout=0.01)
        
        # 启动读取线程
        self.running = True
        self.thread = threading.Thread(target=self.read_loop)
        self.thread.start()
        
        rospy.loginfo("舵机角度读取节点已启动")
        rospy.on_shutdown(self.shutdown)

    def send_read_command(self):
        """发送角度读取指令（严格遵循协议）"""
        cmd = bytearray([0x55, 0x55])
        # 数据长度 = 舵机数 + 3 (指令+长度字段)
        cmd.append(len(self.servo_ids) + 3)
        cmd.append(0x15)  # CMD_MULT_SERVO_POS_READ指令号21(0x15)
        cmd.append(len(self.servo_ids))
        cmd.extend(self.servo_ids)
        self.ser.write(cmd)

    def parse_response(self, data):
        """严格协议解析"""
        try:
            # 基础校验
            if len(data) < 5:
                return None
            if data[0] != 0x55 or data[1] != 0x55:
                return None
            
            # 协议字段解析
            length = data[2]
            cmd = data[3]
            servo_count = data[4]
            
            # 校验指令和长度
            if cmd != 0x15:
                return None
            expected_length = 3 + servo_count*3  # 3=cmd+len+count
            if length != expected_length:
                rospy.logwarn(f"长度不符: 期望{expected_length} 实际{length}")
                return None
            
            # 解析舵机数据
            positions = {}
            index = 5  # 数据起始位置
            for _ in range(servo_count):
                if index+2 >= len(data):
                    break
                sid = data[index]
                # 小端模式组合16位值
                pos = data[index+1] | (data[index+2] << 8)
                positions[sid] = pos
                index += 3
            
            return positions
        except Exception as e:
            rospy.logwarn(f"解析失败: {str(e)}")
            return None

    def read_loop(self):
        """改进的数据读取循环"""
        buffer = bytearray()
        while self.running and not rospy.is_shutdown():
            try:
                # 发送读取请求
                self.send_read_command()
                
                # 读取所有可用数据
                buffer += self.ser.read_all()
                
                # 解析数据包
                while len(buffer) >= 5:
                    # 寻找帧头
                    header_pos = buffer.find(b'\x55\x55')
                    if header_pos == -1:
                        buffer.clear()
                        break
                    
                    # 移除帧头前的垃圾数据
                    if header_pos > 0:
                        buffer = buffer[header_pos:]
                    
                    # 检查数据包完整性
                    if len(buffer) < 5:
                        break
                    
                    length = buffer[2]
                    if len(buffer) < length + 2:  # 2字节帧头
                        break
                    
                    # 提取完整数据包
                    packet = buffer[:length+2]
                    buffer = buffer[length+2:]
                    
                    # 解析数据包
                    positions = self.parse_response(packet)
                    if positions:
                        self.publish_positions(positions)
                
                rospy.sleep(self.read_interval)
            except Exception as e:
                rospy.logerr(f"读取异常: {str(e)}")
                self.running = False

    def publish_positions(self, positions):
        """正确的数据发布方法"""
        try:
            msg = Float32MultiArray()
            angle_list = []
            for sid in self.servo_ids:
                # 获取原始脉冲值（0-1000）
                pulse = positions.get(sid, 0)
                pulse = max(0, min(pulse, 1000))  # 双重限幅
                
                # 转换为角度（0-240度）
                angle = (pulse / 1000.0) * 240.0
                angle_list.append(round(angle, 1))
            
            msg.data = angle_list
            self.pub.publish(msg)
        except Exception as e:
            rospy.logerr(f"发布失败: {str(e)}")

    def shutdown(self):
        """安全关闭"""
        self.running = False
        if self.ser.is_open:
            self.ser.close()
        rospy.loginfo("节点已关闭")

if __name__ == '__main__':
    try:
        reader = ServoReader()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass