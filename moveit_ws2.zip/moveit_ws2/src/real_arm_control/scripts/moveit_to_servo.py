#!/usr/bin/env python3
import rospy
import math
import numpy as np
from moveit_msgs.msg import DisplayTrajectory
import ServoControl

class MoveItServoController:
    def __init__(self):
        rospy.init_node('moveit_servo_controller')
        
        # 关节-舵机映射关系
        self.joint_servo_map = {
            'joint1': 4,    # 0弧度对应120°
            'joint2': 3,    # 0弧度对应217°
            'joint3': 2,    # 0弧度对应120°
            'joint4_left': 1     
        }
        
        # 关节角度转换参数（最终版）
        self.joint_conversion = {
            'joint1': {
                'offset': 120.0,
                'ratio': 1.0  
            },
            'joint2': {
                'offset': 217.0,
                'ratio': -1.0  # joint2减小 → 舵机3增大
            },
            'joint3': {
                'offset': 120.0,
                'ratio': -1.0  # joint3减小 → 舵机2增大
            },
            'joint4_left': {
                'range': {
                    'rad': [0.0, 0.024],    # 输入范围
                    'deg': [160.0, 67.0]    # 输出范围
                }
            }
        }

        # 系统参数
        self.min_pulse = 0
        self.max_pulse = 1000
        self.max_duration = 2000  # 缩短最大运动时间
        
        # 初始化
        self.sub = rospy.Subscriber('/move_group/display_planned_path', 
                                  DisplayTrajectory, 
                                  self.trajectory_callback,
                                  queue_size=1)
        self.validate_joint4_conversion()
        rospy.loginfo("MoveIt舵机控制节点已启动 (最终校准版)")

    def validate_joint4_conversion(self):
        """关节4自检验证"""
        test_cases = [
            (0.0, 160.0, 666),
            (0.024, 67.0, 279),
            (0.012, 113.5, 473)
        ]
        
        for rad, deg, pulse in test_cases:
            # 角度转换验证
            actual_deg = self.convert_joint4_angle(rad)
            deg_error = abs(actual_deg - deg)
            
            # 脉冲转换验证
            actual_pulse = int(actual_deg * 1000 / 240)
            pulse_error = abs(actual_pulse - pulse)
            
            status = "✓" if deg_error <= 0.5 and pulse_error <= 2 else "✗"
            rospy.loginfo(
                f"[{status}] {rad:.3f}rad → "
                f"角度:{actual_deg:.1f}°/{deg}° "
                f"脉冲:{actual_pulse}/{pulse}"
            )
            
            if status == "✗":
                rospy.logerr("关节4校准失败！")
                rospy.signal_shutdown("硬件校准错误")

    def convert_joint4_angle(self, rad_value):
        """精确的线性映射"""
        return np.interp(rad_value,
                       self.joint_conversion['joint4_left']['range']['rad'],
                       self.joint_conversion['joint4_left']['range']['deg'])

    def trajectory_callback(self, msg):
        if not msg.trajectory:
            return
            
        trajectory = msg.trajectory[0].joint_trajectory
        points = trajectory.points
        
        # 预处理轨迹点
        servo_commands = []
        for point in points:
            servos = []
            for j, joint_name in enumerate(trajectory.joint_names):
                if joint_name not in self.joint_servo_map:
                    continue
                
                # 参数计算
                servo_id = self.joint_servo_map[joint_name]
                joint_pos = point.positions[j]
                
                if joint_name == 'joint4_left':
                    angle = self.convert_joint4_angle(joint_pos)
                else:
                    cfg = self.joint_conversion[joint_name]
                    angle = cfg['offset'] + cfg['ratio'] * math.degrees(joint_pos)
                
                # 安全限制
                angle = np.clip(angle, 0.0, 240.0)
                pulse = int(angle * 1000 / 240)
                servos.extend([servo_id, pulse])
            
            if servos:
                # 动态时间计算（原时间的20%）
                time_ms = max(150, min(self.max_duration, 
                                   int(point.time_from_start.to_sec() * 1000 * 0.2)))
                servo_commands.append((servos, time_ms))
        
        # 高速发送指令
        for idx, (servos, time_ms) in enumerate(servo_commands):
            try:
                ServoControl.setMoreBusServoMove(
                    servos=servos,
                    servos_count=len(servos)//2,
                    time=time_ms
                )
                rospy.loginfo(f"轨迹点{idx} | 时间:{time_ms}ms | 脉冲:{servos[1::2]}")
            except Exception as e:
                rospy.logerr(f"控制异常: {str(e)}")
            rospy.sleep(0.005)  # 5ms间隔

if __name__ == '__main__':
    try:
        controller = MoveItServoController()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass